console.log('connecté'); 

// valeur par défaut
let size = 2

btnPlus.addEventListener('click', ()=>{
  console.log("plus");

  // on incrémente
  size = size + 1;
  title.style.fontSize = `${size}rem`;
})

btnMinus.addEventListener("click", () => {
  console.log("moins");

  // on décrémente
  size = size - 1;
  title.style.fontSize = `${size}rem`; 
});

